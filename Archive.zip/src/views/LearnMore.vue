<template>
    <div class="container mx-auto p-6">
      <h1 class="text-3xl font-bold text-center text-blue-600">Learn More</h1>
      <p class="text-gray-700 text-lg mt-4">
        Welcome to the Learn More page! Here, you'll find more details about our project and its purpose.
      </p>
      <router-link to="/" class="text-blue-500 underline mt-4 block text-center">Go Back Home</router-link>
    </div>
  </template>
  
  <script>
  export default {
    name: "LearnMore"
  };
  </script>
  
  <style scoped>
  /* Custom styles if needed */
  </style>
  