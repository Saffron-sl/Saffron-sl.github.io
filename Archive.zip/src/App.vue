<script setup>
import NavBar from './components/NavBar.vue'
</script>

<template>
  <div class="min-h-screen">
    <NavBar />
    <router-view />
  </div>
</template>